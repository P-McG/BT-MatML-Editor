 #!/bin/bash       

xsdcxx cxx-tree --generate-ostream --generate-serialization matml31.xsd

